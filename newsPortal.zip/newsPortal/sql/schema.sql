CREATE TABLE "users"
(
    "id"                   BIGSERIAL PRIMARY KEY,
    "surname"              varchar,
    "name"                 varchar,
    "patronymic"           varchar,
    "email"                varchar,
    "birthday"             date,
    "password"             varchar,
    "sex"                  varchar,
    "country"              varchar,
    "city"                 varchar,
    "reset_password_token" varchar,
    "nickname"             varchar,
    "is_active"            boolean,
    "roles"                varchar(2048),
    "employee_id"          bigint
);

CREATE TABLE "role"
(
    "role_id" SERIAL PRIMARY KEY,
    "name"    varchar
);

CREATE TABLE "user_role"
(
    "user_id" bigint,
    "role_id" bigint
);

CREATE TABLE "employee"
(
    "id"                   BIGSERIAL PRIMARY KEY,
    "date_of_hire"         date,
    "date_of_dismissal"    date,
    "reason_for_dismissal" varchar,
    "avatar"               varchar,
    "date_of_creation"     timestamp,
    "date_of_update"       timestamp,
    "is_on_remote"         boolean,
    "note"                 text,
    "timezone"             varchar,
    "position"             varchar(2048)
);

CREATE TABLE "position"
(
    "id"    SERIAL PRIMARY KEY,
    "name"  varchar,
    "level" varchar
);

CREATE TABLE "employee_position"
(
    "employee_id" bigint,
    "position_id" int
);

CREATE TABLE "contact_info"
(
    "id"              BIGSERIAL PRIMARY KEY,
    "employee_id"     bigint,
    "office_number"   varchar,
    "personal_number" varchar,
    "office_email"    varchar,
    "personal_email"  varchar,
    "telegram_acc"    varchar,
    "skype_acc"       varchar
);

CREATE TABLE "article"
(
    "id"               BIGSERIAL PRIMARY KEY,
    "title"            varchar(400),
    "slug"             varchar,
    "description"      varchar(1000),
    "text"             text,
    "date_of_creation" date,
    "date_of_update"   date,
    "user_id"          bigint,
    "collaborators"    varchar(255),
    "is_moderated"     boolean,
    "is_published"     boolean
);

CREATE TABLE "departments"
(
    "id"                    BIGSERIAL PRIMARY KEY,
    "name"                  varchar,
    "head_of_department_id" bigint
);

CREATE TABLE "user_department"
(
    "user_id"       bigint,
    "department_id" bigint
);

ALTER TABLE "contact_info"
    ADD FOREIGN KEY ("employee_id") REFERENCES "employee" ("id");

ALTER TABLE "users"
    ADD FOREIGN KEY ("employee_id") REFERENCES "employee" ("id");

ALTER TABLE "departments"
    ADD FOREIGN KEY ("head_of_department_id") REFERENCES "users" ("id");

ALTER TABLE "user_department"
    ADD FOREIGN KEY ("user_id") REFERENCES "users" ("id");

ALTER TABLE "user_department"
    ADD FOREIGN KEY ("department_id") REFERENCES "departments" ("id");

ALTER TABLE "article"
    ADD FOREIGN KEY ("user_id") REFERENCES "users" ("id");