package com.example.app.controller.dto;

import lombok.Data;

@Data
public class DepartmentNewWorkerDto {
    private String emailOfWorker;
}
