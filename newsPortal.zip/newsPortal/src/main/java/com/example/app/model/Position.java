package com.example.app.model;

public enum Position {
    BackendDeveloper,
    FrontendDeveloper,
    QATester,
    HRRecruiter,
    CEO,
    HeadHRRecruiter,
    AccountManager,
    BusinessManager,
    ProjectManager,
    MainBookkeeper,
    CTO,
    Lawyer,
    None
}
