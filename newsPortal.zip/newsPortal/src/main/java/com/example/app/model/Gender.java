package com.example.app.model;

public enum Gender {
    MALE,
    FEMALE;
}
