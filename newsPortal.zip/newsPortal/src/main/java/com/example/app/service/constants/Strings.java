package com.example.app.service.constants;

public abstract class Strings {
    public static final String MILLISECONDS = ":00.000000000Z";
}
